#!/bin/sh

if [ $# -lt 2 ]; then
	echo "Usage: indexer.sh <index_dir> <search_word>"
	exit 1
fi


java -cp LuceneSearchIndexJar.jar com.lucene.SearchIndex $1 $2 