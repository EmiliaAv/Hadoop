Run Indexer
sh indexer.sh C:\RunLucene\tweetData C:\RunLucene\tweetIndex

Run Searcher
sh searchIndex.sh C:\RunLucene\tweetIndex girl