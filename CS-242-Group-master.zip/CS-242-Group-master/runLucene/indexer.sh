#!/bin/sh

if [ $# -lt 2 ]; then
	echo "Usage: indexer.sh <tweet_log> <index_dir>"
	exit 1
fi


java -cp LuceneIndexerJar.jar com.lucene.Indexer $1 $2 