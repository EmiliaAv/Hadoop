package com.lucene;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.nio.file.FileVisitResult;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.SimpleFileVisitor;
import java.nio.file.attribute.BasicFileAttributes;
import java.util.Date;

import org.apache.lucene.analysis.Analyzer;
import org.apache.lucene.analysis.standard.StandardAnalyzer;
import org.apache.lucene.document.Document;
import org.apache.lucene.document.Field;
import org.apache.lucene.document.StringField;
import org.apache.lucene.document.TextField;
import org.apache.lucene.index.IndexWriter;
import org.apache.lucene.index.IndexWriterConfig;
import org.apache.lucene.index.IndexWriterConfig.OpenMode;
import org.apache.lucene.index.Term;
import org.apache.lucene.store.Directory;
import org.apache.lucene.store.FSDirectory;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.JSONValue;



public class Indexer
{
    // To stored current tweets counts
    static int CurrentNumOfTweets = 0;
    
    public static void main(String[] args)
    {
    	
		if (args.length < 2) {
			System.out.println("Usage [DataFile] [IndexDir]");
			System.exit(-1);
		}
		
        //Input folder
        String docsPath = args[0];
         
        //Output folder
        String indexPath = args[1];
        
/*        
        //Input folder
        String docsPath = "C:\\runLucene\\tweetData";
         
        //Output folder
        String indexPath = "C:\\runLucene\\tweetIndex";
        */
        //Input Path Variable
        final Path docDir = Paths.get(docsPath);
 
        try
        {
            //org.apache.lucene.store.Directory instance
            Directory dir = FSDirectory.open( Paths.get(indexPath) );
             
            //analyzer with the default stop words
            Analyzer analyzer = new StandardAnalyzer();
             
            //IndexWriter Configuration
            IndexWriterConfig iwc = new IndexWriterConfig(analyzer);
            iwc.setOpenMode(OpenMode.CREATE_OR_APPEND);
             
            //IndexWriter writes new index files to the directory
            IndexWriter writer = new IndexWriter(dir, iwc);
             
            //Just to ensure we don't duplicate.
            writer.deleteAll();
            writer.commit();
            
            Date start = new Date();
            
            //Its recursive method to iterate all files and directories
            indexDocs(writer, docDir);
            
            Date end = new Date();
            
            int numIndex = writer.numDocs();
            System.out.println("Total numer of tweets indexed:  " + numIndex);
            
            System.out.println((end.getTime() - start.getTime())/1000 + " seconds total to index all files.");
            
            writer.close();
        }
        catch (IOException e)
        {
            e.printStackTrace();
        }
    }
     
    static void indexDocs(final IndexWriter writer, Path path) throws IOException
    {
        //Directory?
        if (Files.isDirectory(path))
        {
            //Iterate directory
            Files.walkFileTree(path, new SimpleFileVisitor<Path>()
            {
                @Override
                public FileVisitResult visitFile(Path file, BasicFileAttributes attrs) throws IOException
                {
                    try
                    {
                    	System.out.println("Indexing file: " + file.toString());
                    	Date start = new Date();
                    	
                        //Index this file
                        indexDoc(writer, file, attrs.lastModifiedTime().toMillis());
                        
                        Date end = new Date();
                        System.out.println((end.getTime() - start.getTime())/1000 + " total seconds to index file.");
                    }
                    catch (IOException ioe)
                    {
                        ioe.printStackTrace();
                    }
                    return FileVisitResult.CONTINUE;
                }
            });
        }
        else
        {
            //Index this file
            indexDoc(writer, path, Files.getLastModifiedTime(path).toMillis());
        }
    }  

    /**
     * Add documents to the index
     */

    static void indexDoc(IndexWriter writer, Path file, long lastModified) throws IOException
    {
    	//Get the JSON file
    	
    	InputStream jsonFile = Files.newInputStream(file);
        Reader readerJson = new InputStreamReader(jsonFile);
        
        try
        {
            //Parse the json file using simple-json library
            Object fileObjects= JSONValue.parse(readerJson);
            if(fileObjects != null)
            {
	            JSONArray arrayObjects=(JSONArray)fileObjects;
	            Date start = new Date();
	            
	            for (Object obj : arrayObjects) {
	            	
	            	JSONObject tweets = (JSONObject)obj;
	
	                String screen_name_text = (String) tweets.get("screen_name");
	                String description_text = (String) tweets.get("description");
	                String tweet_text = (String) tweets.get("tweet_text");
	                String place_name = (String) tweets.get("place_name");
	                String hashtags = (String) tweets.get("hashtags");
	                
	                //Create lucene Document
	                Document doc = new Document();
	
	               // doc.add(new StringField("path", file, Field.Store.YES));
	                doc.add(new TextField("screen_name", screen_name_text, Field.Store.YES));
	                doc.add(new TextField("description", description_text, Field.Store.YES));
	                doc.add(new TextField("tweet_text", tweet_text, Field.Store.YES));
	                doc.add(new TextField("place_name", place_name, Field.Store.YES));
	                doc.add(new TextField("hashtags", hashtags, Field.Store.YES));
	                
	              //Updates a document by first deleting the document(s)
	                //containing <code>term</code> and then adding the new
	                //document.  The delete and then add are atomic as seen
	                //by a reader on the same index
	                
	                writer.updateDocument(new Term("screen_name", screen_name_text), doc);
	              //  writer.updateDocument(new Term("path", file.toString()), doc);                
	                //writer.addDocument(doc);
            	
	            }
	            
	            Date end = new Date();
	            int totalTime = (int)(end.getTime() - start.getTime())/1000;
	            		
	            int numIndex = writer.numDocs() - CurrentNumOfTweets;
	            CurrentNumOfTweets = CurrentNumOfTweets + numIndex;
	           // System.out.println((end.getTime() - start.getTime())/1000 + " seconds to index tweets");
	            
	            System.out.format("It took %d seconds to index %d tweets.", totalTime, numIndex);
	            System.out.println("");
            }
        
        }
        catch (Exception ex) {
            throw new RuntimeException(ex);
        }
    } 
    
}
