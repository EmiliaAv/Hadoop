package hadoop;

import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

import java.util.HashMap;

public class InvertedIndexReducer extends Reducer<Text, Text, Text, Text> {

        protected void reduce(Text key, Iterable<Text> values, Context context) throws java.io.IOException, InterruptedException {

            //System.out.println("Starting the REDUCER!!!!");
            StringBuilder stringBuilder = new StringBuilder();
            System.out.println("Key: " + key.toString());

            /*Declare the Hash Map to store File name as key to compute and store number of times the filename is occurred for as value*/
            HashMap hash = new HashMap();
            int count = 0;

            for (Text value : values) {

                System.out.println("Value: " + value.toString());
                stringBuilder.append(value.toString());

                /*See if the doc_id is present in HashMap - if not then add it and increment counter by 1
                 condition is satisfied on first occurence of that word */
                if(hash != null && hash.get(value) != null){
                    count = (int)hash.get(value);
                    hash.put(value, ++count);
                } else {
                    /* else part execute if file name already added
                       then just increase teh count for that file which is stored as key in hashmap
                     */
                    hash.put(value, 1);
                }

                if (values.iterator().hasNext()) {
                    stringBuilder.append(" , ");
                }
            }
            //System.out.println(key + ", " + stringBuilder);
            context.write(key, new Text(hash.toString()));
        }
}


//public static class Reduce extends
//        Reducer<Text, Text, Text, Text> {
//    @Override
//    public void reduce(Text key, Iterable<Text> values, Context context)
//            throws IOException, InterruptedException {
//        /*Declare the Hash Map to store File name as key to compute and store number of times the filename is occurred for as value*/
//        HashMap m=new HashMap();
//        int count=0;
//        for(Text t:values){
//
//            String str=t.toString();
//            /*Check if file name is present in the HashMap ,if File name is not present then add the Filename to the HashMap and increment the counter by one , This condition will be satisfied on first occurrence of that word*/
//            if(m!=null &&m.get(str)!=null){
//                count=(int)m.get(str);
//                m.put(str, ++count);
//            }else{
//                /*Else part will execute if file name is already added then just increase the count for that file name which is stored as key in the hash map*/
//                m.put(str, 1);
//            }
//        }
//        /* Emit word and [file1→count of the word1 in file1 , file2→count of the word1 in file2 ………] as output*/
//        context.write(key, new Text(m.toString()));
//    }
//}

