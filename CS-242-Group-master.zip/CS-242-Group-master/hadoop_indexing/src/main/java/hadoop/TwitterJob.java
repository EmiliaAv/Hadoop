package hadoop;

import java.io.IOException;

import com.uttesh.exude.exception.InvalidDataException;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.mapreduce.Job;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.mongodb.BasicDBObject;
import com.mongodb.hadoop.util.MongoConfigUtil;

public class TwitterJob {

    public static void main(String[] args)
            throws IOException, ClassNotFoundException, InterruptedException, InvalidDataException {

//        if (args.length != 2) {
//            System.err.println("Usage: InvertedIndexJob <input path> <output path>");
//            System.exit(-1);
//        }


//        String str = "Array is the most #important thing in any programming #language";
//        Pattern MY_PATTERN = Pattern.compile("#(\\w+)");
//        Matcher mat = MY_PATTERN.matcher(str);
//        List<String> hashtags = new ArrayList<String>();
//        while (mat.find()) {
//            System.out.println("#" + mat.group(1));
//            hashtags.add("#" + mat.group(1));
//        }

//        String str= "Hello how are you there testing #testing!!!!";
//        //String[] wordArray = str.replaceAll("[^a-zA-Z ]", "").toLowerCase().split("\\s+"); //.split(" ");
//        String testString = ExudeData.getInstance().filterStoppingsKeepDuplicates(str);
//        String[] stringToCharArray = testString.split(" ");
//
//        for(int i=0; i<stringToCharArray.length; i++)
//            System.out.println(stringToCharArray[i]);
//
//        String str2 = "Hello how are you there and also #testing testing string!!!!";
//        String output = ExudeData.getInstance().filterStoppingsKeepDuplicates(str2);
//        //System.out.println(output);

        Job job = new Job();
        job.setJarByClass(hadoop.TwitterJob.class);
        job.setJobName("Inverted Index for Twitter Data");
        System.out.println("JOB IS SET...");

        FileInputFormat.addInputPath(job, new Path(args[0]));
        FileOutputFormat.setOutputPath(job, new Path("src/output/"));
        System.out.println("Added input and output argument paths");

        System.out.println("Starting Mapper...");
        job.setMapperClass(InvertedIndexMapper.class);
        System.out.println("Staring Reducer...");
        job.setReducerClass(hadoop.InvertedIndexReducer.class);

        job.setOutputKeyClass(Text.class);
        job.setOutputValueClass(Text.class);

        job.setInputFormatClass(MultiLineJsonInputFormat.class);
        MultiLineJsonInputFormat.setInputJsonMember(job, "doc_id");

        job.waitForCompletion(true);
    }
}