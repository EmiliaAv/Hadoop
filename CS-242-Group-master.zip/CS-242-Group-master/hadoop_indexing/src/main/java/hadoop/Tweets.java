package hadoop;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties
public class Tweets {

    public String doc_id;
    public String screen_name;
    public String description;
    public String tweet_content;
    public String screen_name_text;
    public String description_text;
    public String tweet_text;
    public String hashtags;
    public String links;
    public String place_type;
    public String place_name;
    public String country;
    public String coords;
    public String created_at;

    public Tweets() {
    }

    public Tweets(String doc_id, String screen_name, String description, String tweet_content, String screen_name_text,
                 String description_text, String tweet_text, String hashtags, String links, String place_type,
                 String place_name, String country, String coords, String created_at){
        this.doc_id = doc_id;
        this.screen_name = screen_name;
        this.description = description;
        this.tweet_content = tweet_content;
        this.screen_name_text = screen_name_text;
        this.description_text = description_text;
        this.tweet_text = tweet_text;
        this.hashtags = hashtags;
        this.links = links;
        this.place_name = place_name;
        this.place_type = place_type;
        this.country = country;
        this.coords = coords;
        this.created_at = created_at;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(doc_id + "=" + tweet_text + "\n");
        //return doc_id + "=" + tweet_text + “\n” ;
        return sb.toString();
    }


}
