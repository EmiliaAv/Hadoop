package hadoop;

import com.google.common.collect.ObjectArrays;
import com.uttesh.exude.ExudeData;
import com.uttesh.exude.exception.InvalidDataException;
import org.apache.commons.lang.ArrayUtils;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;
import org.codehaus.jackson.map.ObjectMapper;

import java.io.IOException;

import java.util.Arrays;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.List;
import java.util.ArrayList;


public class InvertedIndexMapper extends Mapper<LongWritable, Text, Text, Text> {

    public void map(LongWritable key, Text value, Context context) throws IOException, InterruptedException {

        // key object to convert JSON to Java
        ObjectMapper jsonMapper = new ObjectMapper();

        try {
            Text wordText = new Text();
            Text document = new Text();
            Tweets tweets = jsonMapper.readValue(value.toString(), Tweets.class);
            // set the document
            document.set(tweets.doc_id);

            //String[] wordArray = textStr.replaceAll(",", "").replaceAll("  ", " ").split(" "); // this has whole string not parsed
            //String[] wordArray = textStr.replaceAll("[^a-zA-Z ]", "").toLowerCase().split("\\s+"); // removes ALL characters from array and lowercase
            // String[] wordArray = str.replaceAll("[^a-zA-Z #]", "").toLowerCase().split("\\s+"); // does not remove #

            // extract hashtags before processing - append later
            Pattern MY_PATTERN = Pattern.compile("#(\\w+)");
            Matcher mat = MY_PATTERN.matcher(tweets.tweet_text);
            List<String> hashtags = new ArrayList<String>();
            //String[] hashtags = new ArrayList[];
            while (mat.find()) {
                //System.out.println("#" + mat.group(1));
                hashtags.add("#" + mat.group(1));
            }
            String[] hashtagArray = hashtags.toArray(new String[0]);

            // ExudeData takes care of stop words, stem words, lowercasing, removes characters, and does not remove duplicate words in each tweet
            String tweetString = ExudeData.getInstance().filterStoppingsKeepDuplicates(tweets.tweet_text);
            // get array of words and split
            String[] wordArray = tweetString.split(" ");

            // now append hashtagArray to wordArray to account for both words and hashtags in the indexes
            String[] both = (String[]) ArrayUtils.addAll(wordArray, hashtagArray);
//            for(int i=0; i<both.length; i++)
//                System.out.println(both[i]);

            // remove spaces with if/else statement before for loop

            for(int i = 0; i < both.length; i++) {
                // set the wordText
                wordText.set(both[i]);
                //System.out.println(both[i]);
                try {
                    //context.write(new Text(wordArray[i]), document);
                    context.write(wordText, document);
                } catch (IOException e) {
                    e.printStackTrace();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        } catch (IOException ex) {
            ex.printStackTrace();
        } catch (InvalidDataException e) {
            e.printStackTrace();
        }

    }

}





